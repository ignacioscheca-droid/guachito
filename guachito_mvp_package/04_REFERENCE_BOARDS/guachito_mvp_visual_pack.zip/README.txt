GUACHITO MVP — VISUAL ASSET PACK

This pack is a visual prototype/reference set generated from the approved Guachito direction.

CORE SCREENS
01 Onboarding
02 Name your Guachito
03 Choose habits
04 Home
05 Complete habit
06 Adventure ready
07 Story + reward
08 Ranch / shop

CORE ANIMATIONS
05 Achievement: idle → happy → jump → celebrate → return
06 Interaction: idle → salute → mate → pet dog → idle
07 Adventure: idle → walk → ride → return → idle

CHARACTER STATES
idle, saludo, feliz, salta_alegria, toma_mate, acaricia_perro,
piensa, sorprendido, triste, dormido, camina, cabalgando,
celebra_logro, vuelve_aventura

NOTE
These are concept-quality visual references for MVP prototyping. For production, the character should be rebuilt as vector/rigged assets (e.g. Rive/Lottie) so poses can be animated cleanly at arbitrary sizes.
